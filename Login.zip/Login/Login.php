
<html>

<head>
<title>Registration/Login</title>
	<link rel="stylesheet" href="style/style.css" type="text/css">
</head>

<body>
<div class="head-content">
	<div class="Logo-content">
		<ul class="head-text">
			<li class="r-border">
				the Brisbane Help Desk
				<br>Brisbane, Queensland

			</li>
			<li>
				Whenever, &nbsp; Whoever, &nbsp; Wherever
			</li>
		</ul>
	</div>
</div>
	<nav class="navi-bar">
		<div class="navi-content">
			<ul>
				<li class="navi-item">
					<a href="#">Home</a>

				</li>

				<li class="navi-item">
					<a href="#">Services</a>
					<div>
						<ul>
							<li class="sub-navi-menu"><a href="#">Service1</a></li>
							<li class="sub-navi-menu"><a href="#">Service2</a></li>
							<li class="sub-navi-menu"><a href="#">Service3</a></li>
						</ul>
					</div>
				</li>

				<li class="navi-item">
					<a class="r-border" href="#">Contact Us</a>
					<div>
						<ul>
							<li class="sub-navi-menu2"><a href="#">Administrator contact</a></li>
							<li class="sub-navi-menu2"><a href="#">Brisbane Help desk center</a></li>
							<li class="sub-navi-menu2"><a href="#">Volunteer contact</a></li>
						</ul>
					</div>
				</li>

			</ul>
		</div>
	</nav>
	
	<br>
			<h1 class="auto-style2">User registration &amp; Login</h1>
<table style="width:100%">      
	
	<tr>
		<th style="width: 70%">
		<br>
	<h2 class="auto-style2">Sign Up for free</h2> <br>
	
<?php
require_once("db_const.php");
if (!isset($_POST['submit'])) {
?>	<!-- The HTML registration form -->
	<form action="<?=$_SERVER['PHP_SELF']?>" method="post">
		<p class="serif">Username:<input type="text" name="username" style="height: 29px" >
		Password:<input type="password" name="password1" style="height: 29px"></p>  <br> <br>
		<p class="serif">Address</p>  
		<textarea name="address" rows="10" style="width: 632px"></textarea> <br> <br>
		<p class="serif">Mobile  :<input type="text" name="mobile" style="height: 29px" >		
		Email   :<input type="email" name="email" style="height: 29px; width: 250px;" ></p>  <br> <br>
 
		<input type="submit" name="submit" value="Register" class="auto-style1" style="width: 303px; height: 94px">
	</form>
<?php
} 

else {
## connect mysql server
	$mysqli = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
	# check connection
	if ($mysqli->connect_errno) {
		echo "<p>MySQL error no {$mysqli->connect_errno} : {$mysqli->connect_error}</p>";
		exit();
	}
## query database
	# prepare data for insertion
	$User_Name	= $_POST['username'];
	$User_Password	= $_POST['password'];
	$User_Address	= $_POST['address'];
	$User_Mobile	= $_POST['mobile'];
	$User_Email		= $_POST['email'];
 
	# check if username and email exist else insert
	$exists = 0;
	$result = $mysqli->query("SELECT username from users WHERE username = '{$username}' LIMIT 1");
	if ($result->num_rows == 1) {
		$exists = 1;
		$result = $mysqli->query("SELECT email from users WHERE email = '{$email}' LIMIT 1");
		if ($result->num_rows == 1) $exists = 2;	
	} else {
		$result = $mysqli->query("SELECT email from users WHERE email = '{$email}' LIMIT 1");
		if ($result->num_rows == 1) $exists = 3;
	}
 
	if ($exists == 1) echo "<p>Username already exists!</p>";
	else if ($exists == 2) echo "<p>Username and Email already exists!</p>";
	else if ($exists == 3) echo "<p>Email already exists!</p>";
	else {
		# insert data into mysql database
		$sql = "INSERT  INTO `users` (`id`, `username`, `password`, `first_name`, `last_name`, `email`) 
				VALUES (NULL, '{$username}', '{$password}', '{$first_name}', '{$last_name}', '{$email}')";
 
		if ($mysqli->query($sql)) {
			//echo "New Record has id ".$mysqli->insert_id;
			echo "<p>Registred successfully!</p>";
		} else {
			echo "<p>MySQL error no {$mysqli->errno} : {$mysqli->error}</p>";
			exit();
		}
	}
}
?>		

	
	
	
	
	
	
	
	
		</th>
		
		<th style="width: 30%">
		
		<h2 class="auto-style2">Login </h2> <br>

		<?php
if (!isset($_POST['submit'])){
?>
<!-- The HTML login form -->
	<form action="<?=$_SERVER['PHP_SELF']?>" method="post">
		<p class="serif">Username:</p><input type="text" name="username" style="height: 29px"><br>
		<p class="serif">Password:</p> <input type="password" name="password" style="height: 29px"><br > <br>
 
		<input type="submit" name="submit" value="Login" class="auto-style1" style="width: 303px; height: 94px" />
	</form>
<?php
} else {
	require_once("db_const.php");
	$mysqli = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
	# check connection
	if ($mysqli->connect_errno) {
		echo "<p>MySQL error no {$mysqli->connect_errno} : {$mysqli->connect_error}</p>";
		exit();
	}
 
	$username = $_POST['username'];
	$password = $_POST['password'];
 
	$sql = "SELECT * from users WHERE username LIKE '{$username}' AND password LIKE '{$password}' LIMIT 1";
	$result = $mysqli->query($sql);
	if (!$result->num_rows == 1) {
		echo "<p>Invalid username/password combination</p>";
	} else {
		echo "<p>Logged in successfully</p>";
		// do stuffs
	}
}
?>		



		
		</th>
	</tr>	
 </table>
	
</body>

</html>
