<?php
	# mysql db constants DB_HOST, DB_USER, DB_PASS, DB_NAME
	const DB_HOST = 'SERVER';
	const DB_USER = 'USER';
	const DB_PASS = 'PASSWORD';
	const DB_NAME = 'php_mysql_login_system';
?>