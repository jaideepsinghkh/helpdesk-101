
	<footer>
		<div class="siteMap-content">
			<div class="siteMap">

					<div>
						<a href="#" class="footer-menu">Home</a><br>
					</div>

					<div>
						<a href="#" class="footer-menu">Services</a><br>
						<a href="#">-- Service Lists</a>
						<a href="#">-- Plumbers</a>
						<a href="#">-- Electrician</a>
						<a href="#">-- Air conditioning</a>
						<a href="#">-- Building work</a>
						<a href="#">-- Car repairs</a>
					</div>

					<div>
						<a href="#" class="footer-menu">Contact us</a><br>
						<a href="contactus.php">-- Hotline numbers</a>
						<a href="https://goo.gl/maps/2J1xR"><nobr>-- See us on GoogleMap</nobr></a>
					</div>

					<div>
						<a href="#" class="footer-menu">About Us</a>
					</div>

					<div>
						<a href="#" class="footer-menu">Users</a><br>
						<a href="login.php">-- Login</a>
						<a href="signup.php">-- Register</a>
						<br>
						<a href="stafflogin.php">-- Staff Login</a>
						<a href="staffsignup.php">-- Staff Register</a>
					</div>
			</div>
		</div>

		<div class="socials-content">
		<div class="socials">
			<div class="joingroup" style="width: 230px;">
				<nobr>Join our social group on :</nobr>
			</div>
			<div class="facebook">
				<a href="#" >Facebook</a>
			</div>

			<div class="instagram">
				<a href="#">Instagram</a>
			</div>

			<div class="linkedin">
				<a href="#">Linkin</a>
			</div>

			<div class="twitter">
				<a href="#">twitter</a>
			</div>
		</div>
		</div>
		<div class="copyrights">
			<p>&#169; IFB299 Team 41 2C4S. All rights reserved.</p>

		</div>

	</footer>
